import React from 'react'
import { Image, SafeAreaView, ScrollView, StyleSheet, Text,View,TouchableOpacity,TextInput } from 'react-native'
import {
 heightPercentageToDP as hp,
 widthPercentageToDP as wp,
} from 'react-native-responsive-screen'

export default function App() {
 return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
      <View style={styles.image}>
          <Image source={require('./assets/fsicon.png')}  />
          <Text style={styles.financial_text}>FINANCIAL STORE</Text>
      </View>

                  <View>
                        <Text style={styles.financial}>Hello Mr. Vishal Kudmethe</Text>
                  </View>

                        <View>
                                  <Text style= {styles.touch}>Please use Your Touch Id</Text>
                        </View>

                      <View style={styles.fingerprint}>
                      
                                  <TouchableOpacity>
                                  <Image source={require('./assets/fingerprint.png')}  />
                                  </TouchableOpacity>
                                <Text style={styles.or}> Or</Text>
                      </View>

                      <View>
                              <Text style={styles.pin_text}>Login using Your PIN</Text>
                      </View>

                      <View>

                      <TextInput style = {styles.input}
                                underlineColorAndroid = "transparent"
                                />    
                                
                      <TextInput style = {styles.input_second}
                                underlineColorAndroid = "transparent"
                                />    
                      <TextInput style = {styles.input_third}
                                underlineColorAndroid = "transparent"
                                /> 
                    < TextInput style = {styles.input_four}
                                underlineColorAndroid = "transparent"
                                /> 
    </View>
      </ScrollView>
    </SafeAreaView>
 )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  image: {
                  width: wp('70%'),
                  height: hp('30%'),
                  marginTop:50,
                  marginLeft:90,

  },
  financial_text:{
             fontSize: hp('2.6%'),
              marginLeft:6,
              marginTop:5,
              fontWeight:"bold",



  },
  financial:{
                          marginLeft:50,
                          fontSize: hp('3.2%'),
                          fontWeight:"bold",
                          color:" rgb(247, 178, 50)",
                          marginTop:10,
  },
  touch:{
                          marginLeft:50,
                          fontSize: hp('3.3%'),
                          fontWeight:'bold',
                          marginTop:30,

  },
  
  login_text:{
                                fontSize: hp('3.3%'),
                                fontWeight:'bold',
                                marginLeft:55,
                                marginTop:10,



  },
  register:{
                                marginTop:30,
                                marginLeft:90,
                                width:170,
                                borderRadius:15,
                                backgroundColor:'black',
                                height:50,


  },
  register_text:{
                              fontSize: hp('2.6%'),
                              fontWeight:'bold',
                              marginLeft:45,
                              marginTop:10,
                              color:'white'
  },
  fingerprint:{
                    marginLeft:120,
                    marginTop:15,

  },
  or:{
                          fontSize: hp('2.6%'),
                            fontWeight:'bold',
                            marginLeft:40,

  },
  pin_text:{
                      marginLeft:90,
                      fontSize: hp('2.6%'),
                      fontWeight:'bold',
                      marginTop:20,




  },
  input: {
    margin: 15,
    height: 40,
    borderColor: 'orange',
    borderWidth: 3,
    width:50,
    marginLeft:40,
    marginTop:20,

 },
 input_second:{
                        margin: 15,
                        height: 40,
                        borderColor: 'orange',
                        borderWidth: 3,
                        width:50,
                        marginLeft:120,
                        marginTop:-55,             
 },
 input_third:{
                            margin: 15,
                            height: 40,
                            borderColor: 'orange',
                            borderWidth: 3,
                            width:50,
                            marginLeft:200,
                            marginTop:-55,   
 },
 input_four:{
                              margin: 15,
                              height: 40,
                              borderColor: 'orange',
                              borderWidth: 3,
                              width:50,
                              marginLeft:270,
                              marginTop:-55, 
 },
})