import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View ,Image,Button,TouchableOpacity } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
    <View style={styles.image}>
    <Image source={require('./assets/fsicon.png')}  />
    <Text style={styles.financial_text}>FINANCIAL STORE</Text>
    </View>
    <View>
          <Text style={styles.financial}>Hello,Welcome to Financial Store!</Text>
    </View>
    <View>
              <Text style= {styles.wealth}>Lets Begin the Journey of Your Wealth Creation...</Text>
    </View>
    <View style={styles.button}>
    
                <TouchableOpacity>
                   <Text style={styles.login_text}>Login</Text>
                </TouchableOpacity>
    </View>
    <View style={styles.register}>

                <TouchableOpacity>
                    <Text style={styles.register_text}>Register</Text>
                </TouchableOpacity>

    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'whitesmoke',
    
  },
  image:{
              marginTop:70,
              marginLeft:90,

  },
  financial_text:{
              fontSize:18,
              marginLeft:8,
              marginTop:5,
              fontWeight:"bold",



  },
  financial:{
                          marginLeft:15,
                          fontSize:22,
                          fontWeight:"bold",
                          color:" rgb(247, 178, 50)",
                          marginTop:20,
  },
  wealth:{
                          marginLeft:50,
                          fontSize:24,
                          fontStyle:'italic',
                          textDecorationLine:'underline',
                          color:"orange",
                          marginTop:30,

  },
  button:{
                          marginTop:150,
                          marginLeft:90,
                          width:170,
                          borderRadius:15,
                          backgroundColor:'orange',
                          height:50,



  },
  login_text:{
                                fontSize:23,
                                fontWeight:'bold',
                                marginLeft:55,
                                marginTop:10,



  },
  register:{
                                marginTop:30,
                                marginLeft:90,
                                width:170,
                                borderRadius:15,
                                backgroundColor:'black',
                                height:50,


  },
  register_text:{
                              fontSize:23,
                              fontWeight:'bold',
                              marginLeft:45,
                              marginTop:10,
                              color:'white'
  },
});
